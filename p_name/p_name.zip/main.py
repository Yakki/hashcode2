from p_name.file_parser import FileParser
from p_name.file_writer import FileWriter

filename = "me_at_the_zoo"

videos, endpoints, requests, caches = FileParser(filename + ".in").parse_file()

best_requests = max(requests, key=lambda r: r.rank)
best_requests.best_cache.add_video(best_requests.video)

FileWriter(filename + ".out", caches).write_file()

print(best_requests)
